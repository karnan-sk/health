import { Button } from "@/components/ui/button"
import Link from "next/link"
import { useTranslation } from "./language-provider"

export function HeroSection() {
  const { t } = useTranslation()

  return (
    <div className="relative overflow-hidden bg-muted py-16 md:py-24">
      <div className="container mx-auto px-4 relative z-10">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 items-center">
          <div className="text-center md:text-left">
            <h1 className="text-4xl md:text-5xl font-bold tracking-tight mb-4">{t("heroTitle")}</h1>
            <p className="text-xl text-muted-foreground mb-8 max-w-md mx-auto md:mx-0">{t("heroSubtitle")}</p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center md:justify-start">
              <Button asChild size="lg">
                <Link href="/book-appointment">{t("bookAppointment")}</Link>
              </Button>
              <Button asChild variant="outline" size="lg">
                <Link href="/free-consultation">{t("freeConsultation")}</Link>
              </Button>
            </div>
          </div>
          <div className="relative h-64 md:h-auto">
            <img
              src="/placeholder.svg?height=400&width=600"
              alt="Healthcare professionals"
              className="rounded-lg shadow-lg object-cover w-full h-full"
            />
          </div>
        </div>
      </div>
    </div>
  )
}
