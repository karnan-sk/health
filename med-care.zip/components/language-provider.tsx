"use client"

import { createContext, useContext, useState, type ReactNode } from "react"

type Language = "en" | "ta"

interface TranslationContextType {
  language: Language
  setLanguage: (language: Language) => void
  t: (key: string) => string
}

const TranslationContext = createContext<TranslationContextType | undefined>(undefined)

interface LanguageProviderProps {
  children: ReactNode
}

export function LanguageProvider({ children }: LanguageProviderProps) {
  const [language, setLanguage] = useState<Language>("en")

  const translations: Record<Language, Record<string, string>> = {
    en: {
      // Navigation
      home: "Home",
      bookAppointment: "Book Appointment",
      viewAppointments: "View Appointments",
      doctors: "Doctors",
      hospitals: "Hospitals",
      contactUs: "Contact Us",
      aboutUs: "About Us",
      freeConsultation: "Free Consultation",
      helpUs: "Help",

      // Hero Section
      heroTitle: "Your Health Is Our Priority",
      heroSubtitle: "Get the best healthcare services with our expert doctors and modern facilities",

      // Services
      ourServices: "Our Services",
      ourServicesDesc: "We offer a wide range of healthcare services to meet your needs",
      easyAppointments: "Easy Appointments",
      easyAppointmentsDesc: "Book appointments online or via phone with just a few steps",
      specialistDoctors: "Specialist Doctors",
      specialistDoctorsDesc: "Access to highly qualified specialists across various fields",
      emergencyServices: "Emergency Services",
      emergencyServicesDesc: "24/7 emergency care for all medical emergencies",
      patientCenteredCare: "Patient-Centered Care",
      patientCenteredCareDesc: "Personalized care focused on your unique health needs",

      // Featured Sections
      featuredDoctors: "Our Expert Doctors",
      featuredHospitals: "Our Hospitals & Clinics",
      viewAll: "View All",
      bookNow: "Book Now",

      // Appointment Form
      patientName: "Patient Name",
      enterName: "Enter your name",
      age: "Age",
      gender: "Gender",
      male: "Male",
      female: "Female",
      other: "Other",
      mobileNumber: "Mobile Number",
      emailAddress: "Email Address",
      medicalCondition: "Medical Condition",
      describeMedicalCondition: "Please describe your symptoms or medical condition",
      selectDoctor: "Select Doctor",
      selectDoctorPlaceholder: "Choose a doctor",
      reviewDetails: "Review Details",
      reviewYourDetails: "Review Your Details",
      selectedDoctor: "Selected Doctor",
      back: "Back",
      confirmAppointment: "Confirm Appointment",
      appointmentBooked: "Appointment Booked",
      appointmentConfirmation:
        "Your appointment has been successfully booked. You will receive a confirmation shortly.",

      // View Appointments
      yourAppointments: "Your Appointments",
      viewAppointmentsDesc: "View and manage your booked appointments",
      serialNumber: "S.No",
      doctor: "Doctor",
      appointmentDate: "Date & Time",
      status: "Status",
      actions: "Actions",
      prescription: "Prescription",
      noAppointments: "You don't have any appointments yet. Book an appointment to get started.",
      pending: "Pending",
      confirmed: "Confirmed",
      completed: "Completed",
      cancelled: "Cancelled",

      // Prescription
      patientDetails: "Patient Details",
      doctorDetails: "Doctor Details",
      diagnosis: "Diagnosis",
      prescribedMedication: "Prescribed Medication",
      signature: "Signature",
      prescriptionNote: "This is a computer-generated prescription and does not require a physical signature.",

      // Footer
      quickLinks: "Quick Links",
      services: "Services",
      telemedicine: "Telemedicine",
      diagnosticServices: "Diagnostic Services",
      allRightsReserved: "All Rights Reserved",
    },
    ta: {
      // Navigation
      home: "முகப்பு",
      bookAppointment: "சந்திப்பு முன்பதிவு",
      viewAppointments: "சந்திப்புகளைக் காண்க",
      doctors: "மருத்துவர்கள்",
      hospitals: "மருத்துவமனைகள்",
      contactUs: "தொடர்பு கொள்ளுங்கள்",
      aboutUs: "எங்களைப் பற்றி",
      freeConsultation: "இலவச ஆலோசனை",
      helpUs: "உதவி",

      // Hero Section
      heroTitle: "உங்கள் ஆரோக்கியம் எங்கள் முன்னுரிமை",
      heroSubtitle: "எங்கள் நிபுணர் மருத்துவர்கள் மற்றும் நவீன வசதிகளுடன் சிறந்த சுகாதார சேவைகளைப் பெறுங்கள்",

      // Services
      ourServices: "எங்கள் சேவைகள்",
      ourServicesDesc: "உங்கள் தேவைகளைப் பூர்த்தி செய்ய பரந்த அளவிலான சுகாதார சேவைகளை வழங்குகிறோம்",
      easyAppointments: "எளிதான சந்திப்புகள்",
      easyAppointmentsDesc: "சில படிகளில் ஆன்லைனிலோ அல்லது தொலைபேசி வழியாகவோ சந்திப்புகளை முன்பதிவு செய்யுங்கள்",
      specialistDoctors: "நிபுணர் மருத்துவர்கள்",
      specialistDoctorsDesc: "பல்வேறு துறைகளில் உயர் தகுதி வாய்ந்த நிபுணர்களை அணுகுங்கள்",
      emergencyServices: "அவசர சேவைகள்",
      emergencyServicesDesc: "அனைத்து மருத்துவ அவசரங்களுக்கும் 24/7 அவசர பராமரிப்பு",
      patientCenteredCare: "நோயாளி மையப் பராமரிப்பு",
      patientCenteredCareDesc: "உங்கள் தனித்துவமான ஆரோக்கிய தேவைகளில் கவனம் செலுத்திய தனிப்பயனாக்கப்பட்ட பராமரிப்பு",

      // Featured Sections
      featuredDoctors: "எங்கள் நிபுணர் மருத்துவர்கள்",
      featuredHospitals: "எங்கள் மருத்துவமனைகள் & கிளினிக்குகள்",
      viewAll: "அனைத்தையும் காண்க",
      bookNow: "இப்போது முன்பதிவு செய்க",

      // Appointment Form
      patientName: "நோயாளியின் பெயர்",
      enterName: "உங்கள் பெயரை உள்ளிடவும்",
      age: "வயது",
      gender: "பாலினம்",
      male: "ஆண்",
      female: "பெண்",
      other: "மற்றவை",
      mobileNumber: "கைபேசி எண்",
      emailAddress: "மின்னஞ்சல் முகவரி",
      medicalCondition: "மருத்துவ நிலை",
      describeMedicalCondition: "உங்கள் அறிகுறிகள் அல்லது மருத்துவ நிலையை விவரிக்கவும்",
      selectDoctor: "மருத்துவரைத் தேர்ந்தெடுக்கவும்",
      selectDoctorPlaceholder: "ஒரு மருத்துவரைத் தேர்ந்தெடுக்கவும்",
      reviewDetails: "விவரங்களை மதிப்பாய்வு செய்க",
      reviewYourDetails: "உங்கள் விவரங்களை மதிப்பாய்வு செய்க",
      selectedDoctor: "தேர்ந்தெடுக்கப்பட்ட மருத்துவர்",
      back: "பின்செல்",
      confirmAppointment: "சந்திப்பை உறுதிப்படுத்துக",
      appointmentBooked: "சந்திப்பு முன்பதிவு செய்யப்பட்டது",
      appointmentConfirmation: "உங்கள் சந்திப்பு வெற்றிகரமாக முன்பதிவு செய்யப்பட்டுள்ளது. விரைவில் உறுதிப்படுத்தல் பெறுவீர்கள்.",

      // View Appointments
      yourAppointments: "உங்கள் சந்திப்புகள்",
      viewAppointmentsDesc: "உங்கள் முன்பதிவு செய்யப்பட்ட சந்திப்புகளைக் காண்க மற்றும் நிர்வகிக்க",
      serialNumber: "வ.எண்",
      doctor: "மருத்துவர்",
      appointmentDate: "தேதி & நேரம்",
      status: "நிலை",
      actions: "செயல்கள்",
      prescription: "மருந்து சீட்டு",
      noAppointments: "உங்களிடம் இன்னும் எந்த சந்திப்புகளும் இல்லை. தொடங்க ஒரு சந்திப்பை முன்பதிவு செய்யுங்கள்.",
      pending: "நிலுவையில் உள்ளது",
      confirmed: "உறுதிப்படுத்தப்பட்டது",
      completed: "முடிக்கப்பட்டது",
      cancelled: "ரத்து செய்யப்பட்டது",

      // Prescription
      patientDetails: "நோயாளி விவரங்கள்",
      doctorDetails: "மருத்துவர் விவரங்கள்",
      diagnosis: "நோய் கண்டறிதல்",
      prescribedMedication: "பரிந்துரைக்கப்பட்ட மருந்து",
      signature: "கையொப்பம்",
      prescriptionNote: "இது கணினி உருவாக்கிய மருந்து சீட்டு மற்றும் உடல் கையொப்பம் தேவையில்லை.",

      // Footer
      quickLinks: "விரைவு இணைப்புகள்",
      services: "சேவைகள்",
      telemedicine: "தொலைமருத்துவம்",
      diagnosticServices: "நோய் கண்டறியும் சேவைகள்",
      allRightsReserved: "அனைத்து உரிமைகளும் பாதுகாக்கப்பட்டவை",
    },
  }

  const t = (key: string): string => {
    return translations[language][key] || key
  }

  return <TranslationContext.Provider value={{ language, setLanguage, t }}>{children}</TranslationContext.Provider>
}

export const useTranslation = (): TranslationContextType => {
  const context = useContext(TranslationContext)
  if (context === undefined) {
    throw new Error("useTranslation must be used within a LanguageProvider")
  }
  return context
}
