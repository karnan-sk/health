import { Card, CardContent } from "@/components/ui/card"
import { Calendar, Clock, Stethoscope, Users } from "lucide-react"
import { useTranslation } from "./language-provider"

export function ServiceHighlights() {
  const { t } = useTranslation()

  const services = [
    {
      icon: <Calendar className="h-8 w-8 text-primary" />,
      title: "easyAppointments",
      description: "easyAppointmentsDesc",
    },
    {
      icon: <Stethoscope className="h-8 w-8 text-primary" />,
      title: "specialistDoctors",
      description: "specialistDoctorsDesc",
    },
    {
      icon: <Clock className="h-8 w-8 text-primary" />,
      title: "emergencyServices",
      description: "emergencyServicesDesc",
    },
    {
      icon: <Users className="h-8 w-8 text-primary" />,
      title: "patientCenteredCare",
      description: "patientCenteredCareDesc",
    },
  ]

  return (
    <section className="py-12">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <h2 className="text-2xl font-bold mb-2">{t("ourServices")}</h2>
          <p className="text-muted-foreground max-w-2xl mx-auto">{t("ourServicesDesc")}</p>
        </div>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {services.map((service, index) => (
            <Card key={index}>
              <CardContent className="p-6 text-center">
                <div className="flex justify-center mb-4">{service.icon}</div>
                <h3 className="font-medium text-lg mb-2">{t(service.title)}</h3>
                <p className="text-sm text-muted-foreground">{t(service.description)}</p>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </section>
  )
}
