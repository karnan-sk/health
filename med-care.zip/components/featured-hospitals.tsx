import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import Link from "next/link"
import { MapPin } from "lucide-react"
import { useTranslation } from "./language-provider"

export function FeaturedHospitals() {
  const { t } = useTranslation()

  const hospitals = [
    {
      id: 1,
      name: "Apollo Hospitals",
      location: "Chennai",
      image: "/placeholder.svg?height=200&width=400",
    },
    {
      id: 2,
      name: "Fortis Healthcare",
      location: "Bengaluru",
      image: "/placeholder.svg?height=200&width=400",
    },
    {
      id: 3,
      name: "MIOT International",
      location: "Chennai",
      image: "/placeholder.svg?height=200&width=400",
    },
  ]

  return (
    <section className="py-12">
      <div className="container mx-auto px-4">
        <div className="flex justify-between items-center mb-8">
          <h2 className="text-2xl font-bold">{t("featuredHospitals")}</h2>
          <Button asChild variant="ghost">
            <Link href="/hospitals">{t("viewAll")}</Link>
          </Button>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {hospitals.map((hospital) => (
            <Card key={hospital.id} className="overflow-hidden">
              <img
                src={hospital.image || "/placeholder.svg"}
                alt={hospital.name}
                className="w-full h-48 object-cover"
              />
              <CardContent className="p-4">
                <h3 className="font-medium text-lg">{hospital.name}</h3>
                <div className="flex items-center gap-1 text-muted-foreground mt-1">
                  <MapPin className="h-4 w-4" />
                  <span className="text-sm">{hospital.location}</span>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </section>
  )
}
