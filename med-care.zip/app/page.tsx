import { HeroSection } from "@/components/hero-section"
import { FeaturedDoctors } from "@/components/featured-doctors"
import { FeaturedHospitals } from "@/components/featured-hospitals"
import { ServiceHighlights } from "@/components/service-highlights"

export default function Home() {
  return (
    <div className="container mx-auto px-4 py-8">
      <HeroSection />
      <ServiceHighlights />
      <FeaturedDoctors />
      <FeaturedHospitals />
    </div>
  )
}
