"use client"

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Calendar } from "@/components/ui/calendar"
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover"
import { CalendarIcon, CheckCircle2, Clock, MapPin, Phone } from "lucide-react"
import { format } from "date-fns"
import { useState } from "react"

export default function FreeConsultationPage() {
  const [date, setDate] = useState<Date>()

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="text-center mb-8">
        <h1 className="text-3xl font-bold tracking-tight">Free Consultation</h1>
        <p className="text-muted-foreground mt-2 max-w-2xl mx-auto">
          Get expert medical advice without any cost - available in English and Tamil
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 mb-12">
        <Card>
          <CardHeader className="bg-primary/5 border-b">
            <CardTitle>Free Medical Consultation</CardTitle>
            <CardDescription>Schedule a free consultation with our qualified doctors</CardDescription>
          </CardHeader>
          <CardContent className="pt-6">
            <Tabs defaultValue="online" className="w-full">
              <TabsList className="grid w-full grid-cols-2">
                <TabsTrigger value="online">Online Consultation</TabsTrigger>
                <TabsTrigger value="inperson">In-Person Visit</TabsTrigger>
              </TabsList>
              <TabsContent value="online" className="space-y-4 pt-4">
                <form className="space-y-4">
                  <div className="grid grid-cols-1 gap-4">
                    <div className="space-y-2">
                      <label htmlFor="name" className="text-sm font-medium">
                        Full Name
                      </label>
                      <Input id="name" placeholder="Enter your name" />
                    </div>
                    <div className="space-y-2">
                      <label htmlFor="email" className="text-sm font-medium">
                        Email Address
                      </label>
                      <Input id="email" type="email" placeholder="Enter your email" />
                    </div>
                    <div className="space-y-2">
                      <label htmlFor="phone" className="text-sm font-medium">
                        Phone Number
                      </label>
                      <Input id="phone" placeholder="Enter your phone number" />
                    </div>
                    <div className="space-y-2">
                      <label htmlFor="specialty" className="text-sm font-medium">
                        Medical Specialty
                      </label>
                      <Select>
                        <SelectTrigger>
                          <SelectValue placeholder="Select specialty" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="general">General Medicine</SelectItem>
                          <SelectItem value="cardiology">Cardiology</SelectItem>
                          <SelectItem value="neurology">Neurology</SelectItem>
                          <SelectItem value="orthopedics">Orthopedics</SelectItem>
                          <SelectItem value="pediatrics">Pediatrics</SelectItem>
                          <SelectItem value="dermatology">Dermatology</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    <div className="space-y-2">
                      <label htmlFor="date" className="text-sm font-medium">
                        Preferred Date
                      </label>
                      <Popover>
                        <PopoverTrigger asChild>
                          <Button variant={"outline"} className="w-full justify-start text-left font-normal">
                            <CalendarIcon className="mr-2 h-4 w-4" />
                            {date ? format(date, "PPP") : <span>Select date</span>}
                          </Button>
                        </PopoverTrigger>
                        <PopoverContent className="w-auto p-0">
                          <Calendar mode="single" selected={date} onSelect={setDate} initialFocus />
                        </PopoverContent>
                      </Popover>
                    </div>
                    <div className="space-y-2">
                      <label htmlFor="time" className="text-sm font-medium">
                        Preferred Time
                      </label>
                      <Select>
                        <SelectTrigger>
                          <SelectValue placeholder="Select time" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="9am">9:00 AM</SelectItem>
                          <SelectItem value="10am">10:00 AM</SelectItem>
                          <SelectItem value="11am">11:00 AM</SelectItem>
                          <SelectItem value="12pm">12:00 PM</SelectItem>
                          <SelectItem value="2pm">2:00 PM</SelectItem>
                          <SelectItem value="3pm">3:00 PM</SelectItem>
                          <SelectItem value="4pm">4:00 PM</SelectItem>
                          <SelectItem value="5pm">5:00 PM</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    <div className="space-y-2">
                      <label htmlFor="symptoms" className="text-sm font-medium">
                        Brief Description of Symptoms
                      </label>
                      <Textarea
                        id="symptoms"
                        placeholder="Please describe your symptoms or concerns"
                        className="min-h-[100px]"
                      />
                    </div>
                    <div className="space-y-2">
                      <label htmlFor="language" className="text-sm font-medium">
                        Preferred Language
                      </label>
                      <Select defaultValue="english">
                        <SelectTrigger>
                          <SelectValue placeholder="Select language" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="english">English</SelectItem>
                          <SelectItem value="tamil">Tamil</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  </div>
                  <Button type="submit" className="w-full">
                    Schedule Free Consultation
                  </Button>
                </form>
              </TabsContent>
              <TabsContent value="inperson" className="space-y-4 pt-4">
                <form className="space-y-4">
                  <div className="grid grid-cols-1 gap-4">
                    <div className="space-y-2">
                      <label htmlFor="name" className="text-sm font-medium">
                        Full Name
                      </label>
                      <Input id="name" placeholder="Enter your name" />
                    </div>
                    <div className="space-y-2">
                      <label htmlFor="email" className="text-sm font-medium">
                        Email Address
                      </label>
                      <Input id="email" type="email" placeholder="Enter your email" />
                    </div>
                    <div className="space-y-2">
                      <label htmlFor="phone" className="text-sm font-medium">
                        Phone Number
                      </label>
                      <Input id="phone" placeholder="Enter your phone number" />
                    </div>
                    <div className="space-y-2">
                      <label htmlFor="location" className="text-sm font-medium">
                        Preferred Location
                      </label>
                      <Select>
                        <SelectTrigger>
                          <SelectValue placeholder="Select location" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="main">Main Hospital</SelectItem>
                          <SelectItem value="outpatient">Outpatient Center</SelectItem>
                          <SelectItem value="specialty">Specialty Clinic</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    <div className="space-y-2">
                      <label htmlFor="specialty" className="text-sm font-medium">
                        Medical Specialty
                      </label>
                      <Select>
                        <SelectTrigger>
                          <SelectValue placeholder="Select specialty" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="general">General Medicine</SelectItem>
                          <SelectItem value="cardiology">Cardiology</SelectItem>
                          <SelectItem value="neurology">Neurology</SelectItem>
                          <SelectItem value="orthopedics">Orthopedics</SelectItem>
                          <SelectItem value="pediatrics">Pediatrics</SelectItem>
                          <SelectItem value="dermatology">Dermatology</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    <div className="space-y-2">
                      <label htmlFor="date" className="text-sm font-medium">
                        Preferred Date
                      </label>
                      <Popover>
                        <PopoverTrigger asChild>
                          <Button variant={"outline"} className="w-full justify-start text-left font-normal">
                            <CalendarIcon className="mr-2 h-4 w-4" />
                            {date ? format(date, "PPP") : <span>Select date</span>}
                          </Button>
                        </PopoverTrigger>
                        <PopoverContent className="w-auto p-0">
                          <Calendar mode="single" selected={date} onSelect={setDate} initialFocus />
                        </PopoverContent>
                      </Popover>
                    </div>
                    <div className="space-y-2">
                      <label htmlFor="time" className="text-sm font-medium">
                        Preferred Time
                      </label>
                      <Select>
                        <SelectTrigger>
                          <SelectValue placeholder="Select time" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="9am">9:00 AM</SelectItem>
                          <SelectItem value="10am">10:00 AM</SelectItem>
                          <SelectItem value="11am">11:00 AM</SelectItem>
                          <SelectItem value="12pm">12:00 PM</SelectItem>
                          <SelectItem value="2pm">2:00 PM</SelectItem>
                          <SelectItem value="3pm">3:00 PM</SelectItem>
                          <SelectItem value="4pm">4:00 PM</SelectItem>
                          <SelectItem value="5pm">5:00 PM</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    <div className="space-y-2">
                      <label htmlFor="reason" className="text-sm font-medium">
                        Reason for Visit
                      </label>
                      <Textarea
                        id="reason"
                        placeholder="Please describe your symptoms or concerns"
                        className="min-h-[100px]"
                      />
                    </div>
                    <div className="space-y-2">
                      <label htmlFor="language" className="text-sm font-medium">
                        Preferred Language
                      </label>
                      <Select defaultValue="english">
                        <SelectTrigger>
                          <SelectValue placeholder="Select language" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="english">English</SelectItem>
                          <SelectItem value="tamil">Tamil</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  </div>
                  <Button type="submit" className="w-full">
                    Schedule Free Consultation
                  </Button>
                </form>
              </TabsContent>
            </Tabs>
          </CardContent>
        </Card>

        <div className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Free Consultation Benefits</CardTitle>
              <CardDescription>Take advantage of our no-cost medical consultation services</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-start gap-3">
                <CheckCircle2 className="h-5 w-5 text-primary mt-0.5" />
                <div>
                  <h3 className="font-medium">Expert Medical Advice</h3>
                  <p className="text-sm text-muted-foreground">
                    Get professional medical guidance from qualified doctors without any charges
                  </p>
                </div>
              </div>
              <div className="flex items-start gap-3">
                <CheckCircle2 className="h-5 w-5 text-primary mt-0.5" />
                <div>
                  <h3 className="font-medium">Bilingual Support</h3>
                  <p className="text-sm text-muted-foreground">
                    Consultations available in both English and Tamil for your convenience
                  </p>
                </div>
              </div>
              <div className="flex items-start gap-3">
                <CheckCircle2 className="h-5 w-5 text-primary mt-0.5" />
                <div>
                  <h3 className="font-medium">No Hidden Costs</h3>
                  <p className="text-sm text-muted-foreground">
                    Completely free service with no obligation to pursue further treatment
                  </p>
                </div>
              </div>
              <div className="flex items-start gap-3">
                <CheckCircle2 className="h-5 w-5 text-primary mt-0.5" />
                <div>
                  <h3 className="font-medium">Multiple Specialties</h3>
                  <p className="text-sm text-muted-foreground">Access to specialists across various medical fields</p>
                </div>
              </div>
              <div className="flex items-start gap-3">
                <CheckCircle2 className="h-5 w-5 text-primary mt-0.5" />
                <div>
                  <h3 className="font-medium">Flexible Scheduling</h3>
                  <p className="text-sm text-muted-foreground">
                    Choose between online or in-person consultations at your convenience
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Free Consultation Locations</CardTitle>
              <CardDescription>Visit us at any of our locations for your free consultation</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-3">
                <div className="flex items-start gap-3">
                  <MapPin className="h-5 w-5 text-primary mt-0.5 shrink-0" />
                  <div>
                    <h3 className="font-medium">Main Hospital</h3>
                    <p className="text-sm text-muted-foreground">123 Medical Avenue, Chennai, Tamil Nadu 600001</p>
                  </div>
                </div>
                <div className="flex items-center gap-3">
                  <Phone className="h-5 w-5 text-primary shrink-0" />
                  <p className="text-sm">+91 44 2345 6789</p>
                </div>
                <div className="flex items-center gap-3">
                  <Clock className="h-5 w-5 text-primary shrink-0" />
                  <p className="text-sm">Mon-Sat: 9:00 AM - 5:00 PM</p>
                </div>
              </div>

              <div className="space-y-3 pt-3 border-t">
                <div className="flex items-start gap-3">
                  <MapPin className="h-5 w-5 text-primary mt-0.5 shrink-0" />
                  <div>
                    <h3 className="font-medium">Outpatient Center</h3>
                    <p className="text-sm text-muted-foreground">456 Health Street, Chennai, Tamil Nadu 600002</p>
                  </div>
                </div>
                <div className="flex items-center gap-3">
                  <Phone className="h-5 w-5 text-primary shrink-0" />
                  <p className="text-sm">+91 44 2345 6790</p>
                </div>
                <div className="flex items-center gap-3">
                  <Clock className="h-5 w-5 text-primary shrink-0" />
                  <p className="text-sm">Mon-Sat: 10:00 AM - 6:00 PM</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>

      <div className="bg-primary/5 rounded-lg p-6 mb-12">
        <div className="text-center mb-6">
          <h2 className="text-2xl font-bold">Frequently Asked Questions</h2>
          <p className="text-muted-foreground mt-2">Common questions about our free consultation service</p>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div className="space-y-2">
            <h3 className="font-medium">Is the consultation really free?</h3>
            <p className="text-sm text-muted-foreground">
              Yes, our consultation service is completely free of charge. There are no hidden fees or obligations to
              pursue further treatment.
            </p>
          </div>
          <div className="space-y-2">
            <h3 className="font-medium">How long does the consultation last?</h3>
            <p className="text-sm text-muted-foreground">
              Free consultations typically last 15-20 minutes, which is sufficient time for the doctor to understand
              your concerns and provide initial guidance.
            </p>
          </div>
          <div className="space-y-2">
            <h3 className="font-medium">Can I choose my preferred language?</h3>
            <p className="text-sm text-muted-foreground">
              Yes, you can select either English or Tamil as your preferred language for the consultation.
            </p>
          </div>
          <div className="space-y-2">
            <h3 className="font-medium">What should I bring to an in-person consultation?</h3>
            <p className="text-sm text-muted-foreground">
              Please bring any relevant medical records, previous test results, and a list of current medications if
              applicable.
            </p>
          </div>
          <div className="space-y-2">
            <h3 className="font-medium">How do online consultations work?</h3>
            <p className="text-sm text-muted-foreground">
              Online consultations are conducted via video call. You'll receive a link to join the call at your
              scheduled time. Ensure you have a stable internet connection.
            </p>
          </div>
          <div className="space-y-2">
            <h3 className="font-medium">Can I get a prescription during the free consultation?</h3>
            <p className="text-sm text-muted-foreground">
              If medically necessary, the doctor may provide a prescription. However, complex cases might require
              additional appointments.
            </p>
          </div>
        </div>
      </div>

      <div className="text-center">
        <h2 className="text-2xl font-bold mb-4">Ready to Get Started?</h2>
        <p className="text-muted-foreground mb-6 max-w-2xl mx-auto">
          Take the first step towards better health with our free consultation service. No costs, no obligations - just
          expert medical advice when you need it.
        </p>
        <Button size="lg" className="px-8">
          Schedule Your Free Consultation Now
        </Button>
      </div>
    </div>
  )
}
