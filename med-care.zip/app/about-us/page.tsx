import { Card, CardContent } from "@/components/ui/card"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"

export default function AboutUsPage() {
  const testimonials = [
    {
      id: 1,
      name: "Rajesh Mehta",
      avatar: "/placeholder.svg?height=50&width=50",
      role: "Patient",
      content:
        "I had an excellent experience at Apollo Hospitals. The doctors were very knowledgeable and the staff was extremely caring. The facilities are world-class and I received the best treatment possible.",
      hospital: "Apollo Hospitals",
      doctor: "Dr. Rajesh Kumar",
    },
    {
      id: 2,
      name: "Priya Venkatesh",
      avatar: "/placeholder.svg?height=50&width=50",
      role: "Patient",
      content:
        "Fortis Healthcare provided me with exceptional care during my stay. The doctors explained everything clearly and the nursing staff was attentive to all my needs. I highly recommend their services.",
      hospital: "Fortis Healthcare",
      doctor: "Dr. Priya Sharma",
    },
    {
      id: 3,
      name: "Anand Krishnan",
      avatar: "/placeholder.svg?height=50&width=50",
      role: "Patient",
      content:
        "MIOT International has state-of-the-art facilities and a team of highly skilled doctors. My surgery was successful and the post-operative care was excellent. I'm grateful for their expertise.",
      hospital: "MIOT International",
      doctor: "Dr. Anand Patel",
    },
    {
      id: 4,
      name: "Lakshmi Subramaniam",
      avatar: "/placeholder.svg?height=50&width=50",
      role: "Patient",
      content:
        "The pediatric department at Kauvery Hospital is exceptional. Dr. Meena Gupta took great care of my child and was very patient in addressing all our concerns. The child-friendly environment made a big difference.",
      hospital: "Kauvery Hospital",
      doctor: "Dr. Meena Gupta",
    },
  ]

  const achievements = [
    {
      year: "2023",
      title: "Best Multi-Specialty Hospital Network",
      description: "Awarded by Healthcare Excellence Awards",
    },
    {
      year: "2022",
      title: "Excellence in Patient Care",
      description: "Recognized by National Health Association",
    },
    {
      year: "2021",
      title: "Best Hospital for Medical Tourism",
      description: "International Healthcare Summit",
    },
    {
      year: "2020",
      title: "Innovation in Healthcare Technology",
      description: "Digital Health Awards",
    },
    {
      year: "2019",
      title: "Best Hospital Chain in South India",
      description: "South India Healthcare Excellence Awards",
    },
  ]

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="text-center mb-12">
        <h1 className="text-3xl font-bold tracking-tight">About Med Care</h1>
        <p className="text-muted-foreground mt-2 max-w-2xl mx-auto">
          Providing exceptional healthcare services with compassion and expertise for over 25 years
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 mb-16">
        <div>
          <h2 className="text-2xl font-bold mb-4">Our Mission</h2>
          <p className="text-muted-foreground mb-6">
            At Med Care, our mission is to provide accessible, high-quality healthcare services to all individuals,
            regardless of their background or circumstances. We are committed to delivering compassionate care that
            addresses the unique needs of each patient, while maintaining the highest standards of medical excellence.
          </p>
          <p className="text-muted-foreground mb-6">
            We strive to be at the forefront of medical innovation, continuously improving our services and facilities
            to ensure that our patients receive the best possible care. Our team of dedicated healthcare professionals
            works tirelessly to promote health and well-being in our communities, focusing on both treatment and
            prevention.
          </p>
          <h2 className="text-2xl font-bold mb-4 mt-8">Our Vision</h2>
          <p className="text-muted-foreground">
            Our vision is to be the leading healthcare provider in the region, recognized for our clinical excellence,
            patient-centered approach, and innovative healthcare solutions. We aim to create a healthier society by
            expanding access to quality healthcare, advancing medical knowledge through research and education, and
            fostering a culture of continuous improvement and compassionate care.
          </p>
        </div>
        <div className="grid grid-cols-2 gap-4">
          <img
            src="/placeholder.svg?height=300&width=300"
            alt="Modern hospital building"
            className="rounded-lg object-cover w-full h-full"
          />
          <img
            src="/placeholder.svg?height=300&width=300"
            alt="Medical professionals"
            className="rounded-lg object-cover w-full h-full"
          />
          <img
            src="/placeholder.svg?height=300&width=300"
            alt="Advanced medical equipment"
            className="rounded-lg object-cover w-full h-full"
          />
          <img
            src="/placeholder.svg?height=300&width=300"
            alt="Patient care"
            className="rounded-lg object-cover w-full h-full"
          />
        </div>
      </div>

      <div className="mb-16">
        <h2 className="text-2xl font-bold mb-6 text-center">Our Achievements</h2>
        <div className="relative">
          <div className="absolute left-1/2 transform -translate-x-1/2 h-full w-0.5 bg-muted"></div>
          <div className="space-y-12">
            {achievements.map((achievement, index) => (
              <div
                key={index}
                className={`relative flex items-center ${index % 2 === 0 ? "flex-row" : "flex-row-reverse"}`}
              >
                <div className="flex-1"></div>
                <div className="absolute left-1/2 transform -translate-x-1/2 -translate-y-1/2 bg-background border-4 border-primary rounded-full h-8 w-8 flex items-center justify-center">
                  <div className="h-3 w-3 bg-primary rounded-full"></div>
                </div>
                <div className="flex-1">
                  <Card className={`w-full max-w-md ${index % 2 === 0 ? "ml-auto mr-8" : "mr-auto ml-8"}`}>
                    <CardContent className="p-6">
                      <div className="mb-2">
                        <Badge variant="outline" className="text-sm font-medium">
                          {achievement.year}
                        </Badge>
                      </div>
                      <h3 className="text-lg font-bold">{achievement.title}</h3>
                      <p className="text-sm text-muted-foreground mt-1">{achievement.description}</p>
                    </CardContent>
                  </Card>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      <div className="mb-16">
        <h2 className="text-2xl font-bold mb-6 text-center">What Our Patients Say</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {testimonials.map((testimonial) => (
            <Card key={testimonial.id} className="overflow-hidden">
              <CardContent className="p-6">
                <div className="flex items-center gap-4 mb-4">
                  <Avatar>
                    <AvatarImage src={testimonial.avatar || "/placeholder.svg"} alt={testimonial.name} />
                    <AvatarFallback>{testimonial.name.charAt(0)}</AvatarFallback>
                  </Avatar>
                  <div>
                    <h3 className="font-medium">{testimonial.name}</h3>
                    <p className="text-sm text-muted-foreground">{testimonial.role}</p>
                  </div>
                </div>
                <p className="text-muted-foreground mb-4">"{testimonial.content}"</p>
                <div className="flex flex-wrap gap-2">
                  <Badge variant="secondary">{testimonial.hospital}</Badge>
                  <Badge variant="outline">{testimonial.doctor}</Badge>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>

      <div>
        <h2 className="text-2xl font-bold mb-6 text-center">Why Choose Med Care?</h2>
        <Tabs defaultValue="expertise" className="w-full">
          <TabsList className="grid grid-cols-1 md:grid-cols-4 w-full">
            <TabsTrigger value="expertise">Expert Doctors</TabsTrigger>
            <TabsTrigger value="technology">Advanced Technology</TabsTrigger>
            <TabsTrigger value="care">Patient-Centered Care</TabsTrigger>
            <TabsTrigger value="facilities">Modern Facilities</TabsTrigger>
          </TabsList>
          <TabsContent value="expertise" className="p-6 border rounded-lg mt-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <h3 className="text-xl font-bold mb-3">World-Class Medical Expertise</h3>
                <p className="text-muted-foreground mb-4">
                  Our team consists of highly qualified doctors and specialists with extensive experience in their
                  respective fields. Many of our doctors have trained at prestigious institutions around the world and
                  are recognized experts in their specialties.
                </p>
                <p className="text-muted-foreground">
                  We regularly invest in the continuing education and professional development of our medical staff to
                  ensure they stay at the forefront of medical advancements and can provide the best possible care to
                  our patients.
                </p>
              </div>
              <img
                src="/placeholder.svg?height=300&width=500"
                alt="Medical team"
                className="rounded-lg object-cover w-full h-full"
              />
            </div>
          </TabsContent>
          <TabsContent value="technology" className="p-6 border rounded-lg mt-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <img
                src="/placeholder.svg?height=300&width=500"
                alt="Medical technology"
                className="rounded-lg object-cover w-full h-full"
              />
              <div>
                <h3 className="text-xl font-bold mb-3">Cutting-Edge Medical Technology</h3>
                <p className="text-muted-foreground mb-4">
                  Med Care is equipped with the latest medical technologies and diagnostic equipment to ensure accurate
                  diagnosis and effective treatment. Our state-of-the-art facilities include advanced imaging systems,
                  minimally invasive surgical equipment, and specialized treatment units.
                </p>
                <p className="text-muted-foreground">
                  We continuously upgrade our technology to incorporate the latest innovations in healthcare, allowing
                  us to offer treatments that are less invasive, more effective, and lead to faster recovery times for
                  our patients.
                </p>
              </div>
            </div>
          </TabsContent>
          <TabsContent value="care" className="p-6 border rounded-lg mt-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <h3 className="text-xl font-bold mb-3">Compassionate Patient Care</h3>
                <p className="text-muted-foreground mb-4">
                  At Med Care, we believe that healing involves more than just medical treatment. Our patient-centered
                  approach focuses on treating the whole person, addressing not only physical symptoms but also
                  emotional and psychological well-being.
                </p>
                <p className="text-muted-foreground">
                  Our dedicated nursing staff and support personnel are trained to provide compassionate care that
                  respects the dignity and individual needs of each patient. We strive to create a supportive and
                  healing environment where patients feel comfortable, informed, and involved in their care.
                </p>
              </div>
              <img
                src="/placeholder.svg?height=300&width=500"
                alt="Patient care"
                className="rounded-lg object-cover w-full h-full"
              />
            </div>
          </TabsContent>
          <TabsContent value="facilities" className="p-6 border rounded-lg mt-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <img
                src="/placeholder.svg?height=300&width=500"
                alt="Hospital facilities"
                className="rounded-lg object-cover w-full h-full"
              />
              <div>
                <h3 className="text-xl font-bold mb-3">State-of-the-Art Facilities</h3>
                <p className="text-muted-foreground mb-4">
                  Our hospitals and clinics are designed with patient comfort and convenience in mind. From spacious
                  waiting areas to private patient rooms, every aspect of our facilities is created to enhance the
                  healing process and provide a positive experience for patients and their families.
                </p>
                <p className="text-muted-foreground">
                  We maintain the highest standards of cleanliness and safety throughout our facilities, adhering to
                  strict protocols to prevent infections and ensure a safe environment for all. Our modern
                  infrastructure supports efficient care delivery while providing a comfortable setting for recovery.
                </p>
              </div>
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  )
}
