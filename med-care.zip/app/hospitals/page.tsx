import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { MapPin, Phone, Clock } from "lucide-react"
import { Badge } from "@/components/ui/badge"

export default function HospitalsPage() {
  const hospitals = [
    {
      id: 1,
      name: "Apollo Hospitals",
      type: "Multi-Specialty Hospital",
      address: "21 Greams Lane, Chennai, Tamil Nadu 600006",
      phone: "+91 44 2829 3333",
      hours: "24/7",
      specialties: ["Cardiology", "Neurology", "Orthopedics", "Oncology"],
      image: "/placeholder.svg?height=200&width=400",
    },
    {
      id: 2,
      name: "Fortis Healthcare",
      type: "Multi-Specialty Hospital",
      address: "154, Bannerghatta Road, Bengaluru, Karnataka 560076",
      phone: "+91 80 6621 4444",
      hours: "24/7",
      specialties: ["Cardiology", "Gastroenterology", "Neurology", "Urology"],
      image: "/placeholder.svg?height=200&width=400",
    },
    {
      id: 3,
      name: "MIOT International",
      type: "Multi-Specialty Hospital",
      address: "4/112, Mount Poonamalle Road, Chennai, Tamil Nadu 600089",
      phone: "+91 44 4200 2288",
      hours: "24/7",
      specialties: ["Orthopedics", "Cardiology", "Neurology", "Pediatrics"],
      image: "/placeholder.svg?height=200&width=400",
    },
    {
      id: 4,
      name: "Kauvery Hospital",
      type: "Multi-Specialty Hospital",
      address: "199, Luz Church Road, Mylapore, Chennai, Tamil Nadu 600004",
      phone: "+91 44 4000 6000",
      hours: "24/7",
      specialties: ["Cardiology", "Neurology", "Nephrology", "Gastroenterology"],
      image: "/placeholder.svg?height=200&width=400",
    },
    {
      id: 5,
      name: "Sankara Nethralaya",
      type: "Eye Specialty Hospital",
      address: "18, College Road, Chennai, Tamil Nadu 600006",
      phone: "+91 44 2827 1616",
      hours: "8:00 AM - 8:00 PM",
      specialties: ["Ophthalmology", "Eye Surgery", "Retina Care"],
      image: "/placeholder.svg?height=200&width=400",
    },
    {
      id: 6,
      name: "Dr. Kamakshi Memorial Hospital",
      type: "Multi-Specialty Hospital",
      address: "1, Radial Road, Pallikaranai, Chennai, Tamil Nadu 600100",
      phone: "+91 44 6630 0300",
      hours: "24/7",
      specialties: ["Obstetrics", "Gynecology", "Pediatrics", "General Medicine"],
      image: "/placeholder.svg?height=200&width=400",
    },
  ]

  const clinics = [
    {
      id: 1,
      name: "Chennai Diabetes Centre",
      type: "Specialty Clinic",
      address: "25, Nungambakkam High Road, Chennai, Tamil Nadu 600034",
      phone: "+91 44 2822 2345",
      hours: "9:00 AM - 7:00 PM",
      specialties: ["Diabetology", "Endocrinology"],
      image: "/placeholder.svg?height=200&width=400",
    },
    {
      id: 2,
      name: "Skin & Cosmetology Centre",
      type: "Specialty Clinic",
      address: "42, Cathedral Road, Chennai, Tamil Nadu 600086",
      phone: "+91 44 2811 5678",
      hours: "10:00 AM - 8:00 PM",
      specialties: ["Dermatology", "Cosmetology"],
      image: "/placeholder.svg?height=200&width=400",
    },
    {
      id: 3,
      name: "Chennai Dental Care",
      type: "Dental Clinic",
      address: "78, Anna Nagar East, Chennai, Tamil Nadu 600102",
      phone: "+91 44 2626 7890",
      hours: "9:00 AM - 9:00 PM",
      specialties: ["General Dentistry", "Orthodontics", "Dental Surgery"],
      image: "/placeholder.svg?height=200&width=400",
    },
    {
      id: 4,
      name: "Mind Wellness Clinic",
      type: "Specialty Clinic",
      address: "12, Adyar, Chennai, Tamil Nadu 600020",
      phone: "+91 44 2445 9876",
      hours: "9:00 AM - 6:00 PM",
      specialties: ["Psychiatry", "Psychology", "Counseling"],
      image: "/placeholder.svg?height=200&width=400",
    },
  ]

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="text-center mb-8">
        <h1 className="text-3xl font-bold tracking-tight">Our Network of Hospitals & Clinics</h1>
        <p className="text-muted-foreground mt-2">Find the best healthcare facilities in your area</p>
      </div>

      <div className="mb-12">
        <h2 className="text-2xl font-bold mb-6">Hospitals</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {hospitals.map((hospital) => (
            <Card key={hospital.id} className="overflow-hidden">
              <img
                src={hospital.image || "/placeholder.svg"}
                alt={hospital.name}
                className="w-full h-48 object-cover"
              />
              <CardHeader className="pb-2">
                <CardTitle>{hospital.name}</CardTitle>
                <CardDescription>{hospital.type}</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  <div className="flex items-start gap-2">
                    <MapPin className="h-4 w-4 mt-1 text-muted-foreground shrink-0" />
                    <span className="text-sm">{hospital.address}</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Phone className="h-4 w-4 text-muted-foreground" />
                    <span className="text-sm">{hospital.phone}</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Clock className="h-4 w-4 text-muted-foreground" />
                    <span className="text-sm">{hospital.hours}</span>
                  </div>
                  <div className="flex flex-wrap gap-1 mt-3">
                    {hospital.specialties.map((specialty) => (
                      <Badge key={specialty} variant="outline" className="text-xs">
                        {specialty}
                      </Badge>
                    ))}
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>

      <div>
        <h2 className="text-2xl font-bold mb-6">Specialty Clinics</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {clinics.map((clinic) => (
            <Card key={clinic.id} className="overflow-hidden">
              <img src={clinic.image || "/placeholder.svg"} alt={clinic.name} className="w-full h-48 object-cover" />
              <CardHeader className="pb-2">
                <CardTitle>{clinic.name}</CardTitle>
                <CardDescription>{clinic.type}</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  <div className="flex items-start gap-2">
                    <MapPin className="h-4 w-4 mt-1 text-muted-foreground shrink-0" />
                    <span className="text-sm">{clinic.address}</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Phone className="h-4 w-4 text-muted-foreground" />
                    <span className="text-sm">{clinic.phone}</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Clock className="h-4 w-4 text-muted-foreground" />
                    <span className="text-sm">{clinic.hours}</span>
                  </div>
                  <div className="flex flex-wrap gap-1 mt-3">
                    {clinic.specialties.map((specialty) => (
                      <Badge key={specialty} variant="outline" className="text-xs">
                        {specialty}
                      </Badge>
                    ))}
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </div>
  )
}
