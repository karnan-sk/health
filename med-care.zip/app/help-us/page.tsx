import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion"
import { FileText, Headphones, HelpCircle, Mic, Phone, PlayCircle } from "lucide-react"

export default function HelpUsPage() {
  return (
    <div className="container mx-auto px-4 py-8">
      <div className="text-center mb-8">
        <h1 className="text-3xl font-bold tracking-tight">Help Center</h1>
        <p className="text-muted-foreground mt-2 max-w-2xl mx-auto">
          Get assistance and learn how to use our services effectively
        </p>
      </div>

      <Tabs defaultValue="guide" className="w-full mb-12">
        <TabsList className="grid w-full grid-cols-1 md:grid-cols-4">
          <TabsTrigger value="guide">User Guide</TabsTrigger>
          <TabsTrigger value="voice">Voice Assistance</TabsTrigger>
          <TabsTrigger value="faq">FAQs</TabsTrigger>
          <TabsTrigger value="contact">Contact Support</TabsTrigger>
        </TabsList>

        <TabsContent value="guide" className="pt-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            <Card>
              <CardHeader>
                <CardTitle>Getting Started</CardTitle>
                <CardDescription>Learn the basics of using Med Care services</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <div className="flex items-center gap-2">
                    <FileText className="h-5 w-5 text-primary" />
                    <h3 className="font-medium">User Guide (English)</h3>
                  </div>
                  <p className="text-sm text-muted-foreground">
                    A comprehensive guide to using our healthcare services, booking appointments, and accessing your
                    medical records.
                  </p>
                  <Button variant="outline" size="sm" className="mt-1">
                    Download PDF
                  </Button>
                </div>

                <div className="space-y-2">
                  <div className="flex items-center gap-2">
                    <FileText className="h-5 w-5 text-primary" />
                    <h3 className="font-medium">User Guide (Tamil)</h3>
                  </div>
                  <p className="text-sm text-muted-foreground">
                    எங்கள் மருத்துவ சேவைகளைப் பயன்படுத்துதல், சந்திப்புகளை முன்பதிவு செய்தல் மற்றும் உங்கள் மருத்துவ பதிவுகளை அணுகுவதற்கான
                    விரிவான வழிகாட்டி.
                  </p>
                  <Button variant="outline" size="sm" className="mt-1">
                    PDF பதிவிறக்கம்
                  </Button>
                </div>

                <div className="space-y-2">
                  <div className="flex items-center gap-2">
                    <PlayCircle className="h-5 w-5 text-primary" />
                    <h3 className="font-medium">Video Tutorials</h3>
                  </div>
                  <p className="text-sm text-muted-foreground">
                    Watch step-by-step video guides on how to navigate our website and use our services.
                  </p>
                  <div className="grid grid-cols-2 gap-2 mt-2">
                    <Button variant="outline" size="sm">
                      English Videos
                    </Button>
                    <Button variant="outline" size="sm">
                      Tamil Videos
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Appointment Process</CardTitle>
                <CardDescription>Understanding how to book and manage appointments</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex items-center gap-4 p-4 bg-muted rounded-lg">
                    <div className="bg-primary text-primary-foreground rounded-full w-8 h-8 flex items-center justify-center font-bold">
                      1
                    </div>
                    <div>
                      <h3 className="font-medium">Create an Account</h3>
                      <p className="text-sm text-muted-foreground">
                        Register on our website or visit our reception desk
                      </p>
                    </div>
                  </div>

                  <div className="flex items-center gap-4 p-4 bg-muted rounded-lg">
                    <div className="bg-primary text-primary-foreground rounded-full w-8 h-8 flex items-center justify-center font-bold">
                      2
                    </div>
                    <div>
                      <h3 className="font-medium">Book an Appointment</h3>
                      <p className="text-sm text-muted-foreground">Select your preferred doctor, date, and time</p>
                    </div>
                  </div>

                  <div className="flex items-center gap-4 p-4 bg-muted rounded-lg">
                    <div className="bg-primary text-primary-foreground rounded-full w-8 h-8 flex items-center justify-center font-bold">
                      3
                    </div>
                    <div>
                      <h3 className="font-medium">Receive Confirmation</h3>
                      <p className="text-sm text-muted-foreground">Get confirmation via email and SMS</p>
                    </div>
                  </div>

                  <div className="flex items-center gap-4 p-4 bg-muted rounded-lg">
                    <div className="bg-primary text-primary-foreground rounded-full w-8 h-8 flex items-center justify-center font-bold">
                      4
                    </div>
                    <div>
                      <h3 className="font-medium">Visit the Doctor</h3>
                      <p className="text-sm text-muted-foreground">Arrive 15 minutes before your appointment time</p>
                    </div>
                  </div>

                  <div className="flex items-center gap-4 p-4 bg-muted rounded-lg">
                    <div className="bg-primary text-primary-foreground rounded-full w-8 h-8 flex items-center justify-center font-bold">
                      5
                    </div>
                    <div>
                      <h3 className="font-medium">Follow-up</h3>
                      <p className="text-sm text-muted-foreground">
                        Access your prescription and schedule follow-up visits if needed
                      </p>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="voice" className="pt-6">
          <Card>
            <CardHeader>
              <CardTitle>Voice Assistance</CardTitle>
              <CardDescription>Get help through our voice assistance service</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                <div className="space-y-4">
                  <div className="bg-muted p-6 rounded-lg text-center">
                    <Mic className="h-12 w-12 mx-auto text-primary mb-4" />
                    <h3 className="text-lg font-medium mb-2">Record Your Question</h3>
                    <p className="text-sm text-muted-foreground mb-4">
                      Click the button below to record your question in English or Tamil. Our system will process your
                      query and provide assistance.
                    </p>
                    <Button className="gap-2">
                      <Mic className="h-4 w-4" />
                      Start Recording
                    </Button>
                  </div>

                  <div className="space-y-2">
                    <h3 className="font-medium">How Voice Assistance Works</h3>
                    <p className="text-sm text-muted-foreground">
                      Our voice assistance system uses advanced speech recognition technology to understand your queries
                      in both English and Tamil. Simply record your question, and our system will process it to provide
                      you with the information you need.
                    </p>
                    <p className="text-sm text-muted-foreground">
                      You can ask questions about our services, appointment procedures, doctor specialties, hospital
                      locations, and more. If your query requires human assistance, it will be forwarded to our support
                      team who will contact you promptly.
                    </p>
                  </div>
                </div>

                <div className="space-y-4">
                  <h3 className="font-medium">Sample Voice Commands</h3>
                  <div className="space-y-3">
                    <div className="bg-muted p-3 rounded-lg">
                      <p className="text-sm font-medium">English:</p>
                      <p className="text-sm">"How do I book an appointment with a cardiologist?"</p>
                    </div>
                    <div className="bg-muted p-3 rounded-lg">
                      <p className="text-sm font-medium">Tamil:</p>
                      <p className="text-sm">"நான் ஒரு இதய மருத்துவரிடம் சந்திப்பை எவ்வாறு முன்பதிவு செய்வது?"</p>
                    </div>
                    <div className="bg-muted p-3 rounded-lg">
                      <p className="text-sm font-medium">English:</p>
                      <p className="text-sm">"What documents do I need to bring for my first visit?"</p>
                    </div>
                    <div className="bg-muted p-3 rounded-lg">
                      <p className="text-sm font-medium">Tamil:</p>
                      <p className="text-sm">"என் முதல் வருகைக்கு நான் என்ன ஆவணங்களைக் கொண்டு வர வேண்டும்?"</p>
                    </div>
                    <div className="bg-muted p-3 rounded-lg">
                      <p className="text-sm font-medium">English:</p>
                      <p className="text-sm">"How can I access my medical records online?"</p>
                    </div>
                    <div className="bg-muted p-3 rounded-lg">
                      <p className="text-sm font-medium">Tamil:</p>
                      <p className="text-sm">"நான் எனது மருத்துவ பதிவுகளை ஆன்லைனில் எவ்வாறு அணுகலாம்?"</p>
                    </div>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="faq" className="pt-6">
          <Card>
            <CardHeader>
              <CardTitle>Frequently Asked Questions</CardTitle>
              <CardDescription>Find answers to common questions about our services</CardDescription>
            </CardHeader>
            <CardContent>
              <Tabs defaultValue="general" className="w-full">
                <TabsList className="grid w-full grid-cols-1 md:grid-cols-4 mb-4">
                  <TabsTrigger value="general">General</TabsTrigger>
                  <TabsTrigger value="appointments">Appointments</TabsTrigger>
                  <TabsTrigger value="billing">Billing</TabsTrigger>
                  <TabsTrigger value="services">Services</TabsTrigger>
                </TabsList>

                <TabsContent value="general">
                  <Accordion type="single" collapsible className="w-full">
                    <AccordionItem value="item-1">
                      <AccordionTrigger>What are your hospital working hours?</AccordionTrigger>
                      <AccordionContent>
                        Our main hospital is open 24/7 for emergency services. The outpatient departments operate from
                        8:00 AM to 8:00 PM, Monday through Saturday. Specialty clinics have varying hours, which you can
                        check on our Hospitals page.
                      </AccordionContent>
                    </AccordionItem>
                    <AccordionItem value="item-2">
                      <AccordionTrigger>Do you offer services in Tamil?</AccordionTrigger>
                      <AccordionContent>
                        Yes, we offer all our services in both English and Tamil. Our staff is fluent in both languages,
                        and all our documentation is available in both languages as well.
                      </AccordionContent>
                    </AccordionItem>
                    <AccordionItem value="item-3">
                      <AccordionTrigger>How can I access my medical records?</AccordionTrigger>
                      <AccordionContent>
                        You can access your medical records through our patient portal. Simply log in with your
                        credentials, and you'll be able to view your medical history, test results, prescriptions, and
                        appointment details. If you need assistance, please contact our help desk.
                      </AccordionContent>
                    </AccordionItem>
                    <AccordionItem value="item-4">
                      <AccordionTrigger>What insurance plans do you accept?</AccordionTrigger>
                      <AccordionContent>
                        We accept most major insurance plans, including government health schemes. Please check with our
                        billing department or your insurance provider to confirm coverage details before your visit.
                      </AccordionContent>
                    </AccordionItem>
                  </Accordion>
                </TabsContent>

                <TabsContent value="appointments">
                  <Accordion type="single" collapsible className="w-full">
                    <AccordionItem value="item-1">
                      <AccordionTrigger>How do I book an appointment?</AccordionTrigger>
                      <AccordionContent>
                        You can book an appointment through our website, mobile app, or by calling our appointment desk.
                        You'll need to provide your personal details, select a doctor or specialty, and choose your
                        preferred date and time.
                      </AccordionContent>
                    </AccordionItem>
                    <AccordionItem value="item-2">
                      <AccordionTrigger>Can I reschedule or cancel my appointment?</AccordionTrigger>
                      <AccordionContent>
                        Yes, you can reschedule or cancel your appointment through our website or app. Please do so at
                        least 24 hours in advance to avoid any cancellation fees and to allow other patients to use the
                        slot.
                      </AccordionContent>
                    </AccordionItem>
                    <AccordionItem value="item-3">
                      <AccordionTrigger>What should I bring to my appointment?</AccordionTrigger>
                      <AccordionContent>
                        Please bring your ID, insurance card (if applicable), any relevant medical records or test
                        results, a list of current medications, and your appointment confirmation. If it's your first
                        visit, please arrive 15 minutes early to complete registration.
                      </AccordionContent>
                    </AccordionItem>
                    <AccordionItem value="item-4">
                      <AccordionTrigger>How long do appointments typically last?</AccordionTrigger>
                      <AccordionContent>
                        Regular consultations typically last 15-20 minutes. Specialized consultations or procedures may
                        take longer. If you have complex medical issues, please inform our staff when booking so they
                        can allocate appropriate time.
                      </AccordionContent>
                    </AccordionItem>
                  </Accordion>
                </TabsContent>

                <TabsContent value="billing">
                  <Accordion type="single" collapsible className="w-full">
                    <AccordionItem value="item-1">
                      <AccordionTrigger>How can I pay for my services?</AccordionTrigger>
                      <AccordionContent>
                        We accept cash, credit/debit cards, and online payments. You can also pay through our patient
                        portal or mobile app. For insured patients, we will bill your insurance directly after
                        collecting any applicable copayments.
                      </AccordionContent>
                    </AccordionItem>
                    <AccordionItem value="item-2">
                      <AccordionTrigger>Do you offer financial assistance?</AccordionTrigger>
                      <AccordionContent>
                        Yes, we offer financial assistance programs for eligible patients. Please contact our financial
                        counseling department to learn about the options available to you and the application process.
                      </AccordionContent>
                    </AccordionItem>
                    <AccordionItem value="item-3">
                      <AccordionTrigger>How can I get a cost estimate for a procedure?</AccordionTrigger>
                      <AccordionContent>
                        You can request a cost estimate by contacting our billing department. Please provide details
                        about the procedure and your insurance information. We'll provide you with an estimate of your
                        out-of-pocket costs.
                      </AccordionContent>
                    </AccordionItem>
                    <AccordionItem value="item-4">
                      <AccordionTrigger>When will I receive my bill?</AccordionTrigger>
                      <AccordionContent>
                        You will typically receive your bill within 30 days of service. If you have insurance, we will
                        bill your insurance first and then send you a bill for any remaining balance after receiving the
                        insurance payment.
                      </AccordionContent>
                    </AccordionItem>
                  </Accordion>
                </TabsContent>

                <TabsContent value="services">
                  <Accordion type="single" collapsible className="w-full">
                    <AccordionItem value="item-1">
                      <AccordionTrigger>What specialties do you offer?</AccordionTrigger>
                      <AccordionContent>
                        We offer a wide range of specialties including Cardiology, Neurology, Orthopedics, Pediatrics,
                        Gynecology, Dermatology, ENT, Ophthalmology, Psychiatry, and more. You can view the complete
                        list on our Doctors page.
                      </AccordionContent>
                    </AccordionItem>
                    <AccordionItem value="item-2">
                      <AccordionTrigger>Do you offer emergency services?</AccordionTrigger>
                      <AccordionContent>
                        Yes, our main hospital provides 24/7 emergency services. Our emergency department is equipped to
                        handle all types of medical emergencies and is staffed by experienced emergency physicians and
                        nurses.
                      </AccordionContent>
                    </AccordionItem>
                    <AccordionItem value="item-3">
                      <AccordionTrigger>What diagnostic services are available?</AccordionTrigger>
                      <AccordionContent>
                        We offer comprehensive diagnostic services including laboratory tests, X-rays, CT scans, MRI,
                        ultrasound, ECG, EEG, endoscopy, and more. Our diagnostic centers use state-of-the-art equipment
                        for accurate and timely results.
                      </AccordionContent>
                    </AccordionItem>
                    <AccordionItem value="item-4">
                      <AccordionTrigger>Do you offer telemedicine services?</AccordionTrigger>
                      <AccordionContent>
                        Yes, we offer telemedicine consultations for many specialties. You can book a video consultation
                        through our website or app. Telemedicine is convenient for follow-up appointments, minor health
                        concerns, and situations where in-person visits are difficult.
                      </AccordionContent>
                    </AccordionItem>
                  </Accordion>
                </TabsContent>
              </Tabs>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="contact" className="pt-6">
          <Card>
            <CardHeader>
              <CardTitle>Contact Support</CardTitle>
              <CardDescription>Get in touch with our support team for assistance</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                <div className="space-y-6">
                  <div className="bg-muted p-6 rounded-lg">
                    <div className="flex items-center gap-3 mb-4">
                      <Phone className="h-6 w-6 text-primary" />
                      <h3 className="text-lg font-medium">Helpline Numbers</h3>
                    </div>
                    <div className="space-y-3">
                      <div>
                        <p className="text-sm font-medium">General Inquiries:</p>
                        <p className="text-lg">+91 44 2345 6789</p>
                      </div>
                      <div>
                        <p className="text-sm font-medium">Appointment Desk:</p>
                        <p className="text-lg">+91 44 2345 6790</p>
                      </div>
                      <div>
                        <p className="text-sm font-medium">Technical Support:</p>
                        <p className="text-lg">+91 44 2345 6791</p>
                      </div>
                      <div>
                        <p className="text-sm font-medium">Billing Inquiries:</p>
                        <p className="text-lg">+91 44 2345 6792</p>
                      </div>
                    </div>
                    <p className="text-sm text-muted-foreground mt-4">
                      Our helplines are available from 8:00 AM to 8:00 PM, Monday through Saturday.
                    </p>
                  </div>

                  <div className="bg-muted p-6 rounded-lg">
                    <div className="flex items-center gap-3 mb-4">
                      <Headphones className="h-6 w-6 text-primary" />
                      <h3 className="text-lg font-medium">Live Chat Support</h3>
                    </div>
                    <p className="text-sm text-muted-foreground mb-4">
                      Chat with our support team in real-time for immediate assistance with your queries.
                    </p>
                    <Button className="w-full">Start Live Chat</Button>
                  </div>
                </div>

                <div className="space-y-6">
                  <div className="bg-muted p-6 rounded-lg">
                    <div className="flex items-center gap-3 mb-4">
                      <HelpCircle className="h-6 w-6 text-primary" />
                      <h3 className="text-lg font-medium">Submit a Support Ticket</h3>
                    </div>
                    <form className="space-y-4">
                      <div className="space-y-2">
                        <label htmlFor="name" className="text-sm font-medium">
                          Full Name
                        </label>
                        <input id="name" className="w-full px-3 py-2 border rounded-md" placeholder="Enter your name" />
                      </div>
                      <div className="space-y-2">
                        <label htmlFor="email" className="text-sm font-medium">
                          Email Address
                        </label>
                        <input
                          id="email"
                          type="email"
                          className="w-full px-3 py-2 border rounded-md"
                          placeholder="Enter your email"
                        />
                      </div>
                      <div className="space-y-2">
                        <label htmlFor="category" className="text-sm font-medium">
                          Issue Category
                        </label>
                        <select id="category" className="w-full px-3 py-2 border rounded-md">
                          <option value="">Select category</option>
                          <option value="technical">Technical Issue</option>
                          <option value="appointment">Appointment Problem</option>
                          <option value="billing">Billing Question</option>
                          <option value="medical">Medical Records</option>
                          <option value="other">Other</option>
                        </select>
                      </div>
                      <div className="space-y-2">
                        <label htmlFor="message" className="text-sm font-medium">
                          Message
                        </label>
                        <textarea
                          id="message"
                          className="w-full px-3 py-2 border rounded-md min-h-[100px]"
                          placeholder="Describe your issue"
                        ></textarea>
                      </div>
                      <Button type="submit" className="w-full">
                        Submit Ticket
                      </Button>
                    </form>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      <div className="text-center">
        <h2 className="text-2xl font-bold mb-4">Need More Help?</h2>
        <p className="text-muted-foreground mb-6 max-w-2xl mx-auto">
          Our support team is always ready to assist you with any questions or concerns you may have about our services.
        </p>
        <div className="flex flex-col sm:flex-row justify-center gap-4">
          <Button size="lg" className="gap-2">
            <Phone className="h-4 w-4" />
            Call Helpline
          </Button>
          <Button size="lg" variant="outline" className="gap-2">
            <Mic className="h-4 w-4" />
            Voice Assistance
          </Button>
        </div>
      </div>
    </div>
  )
}
