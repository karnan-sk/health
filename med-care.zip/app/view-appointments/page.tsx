"use client"

import { useEffect, useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Download } from "lucide-react"
import { useTranslation } from "@/components/language-provider"

interface Appointment {
  id: string
  name: string
  age: string
  gender: string
  mobile: string
  email: string
  disease: string
  doctorId: string
  date: string
  status: string
}

export default function ViewAppointmentsPage() {
  const { t } = useTranslation()
  const [appointments, setAppointments] = useState<Appointment[]>([])
  const [selectedAppointment, setSelectedAppointment] = useState<Appointment | null>(null)

  const doctors = [
    { id: "1", name: "Dr. Rajesh Kumar", specialty: "Cardiology" },
    { id: "2", name: "Dr. Priya Sharma", specialty: "Neurology" },
    { id: "3", name: "Dr. Anand Patel", specialty: "Orthopedics" },
    { id: "4", name: "Dr. Meena Gupta", specialty: "Pediatrics" },
    { id: "5", name: "Dr. Suresh Reddy", specialty: "Dermatology" },
  ]

  useEffect(() => {
    // In a real app, you would fetch this data from your backend
    const storedAppointments = JSON.parse(localStorage.getItem("appointments") || "[]")
    setAppointments(storedAppointments)
  }, [])

  const getDoctorName = (doctorId: string) => {
    const doctor = doctors.find((d) => d.id === doctorId)
    return doctor ? doctor.name : "Unknown Doctor"
  }

  const formatDate = (dateString: string) => {
    const date = new Date(dateString)
    return date.toLocaleDateString() + " " + date.toLocaleTimeString()
  }

  const downloadPrescription = (appointment: Appointment) => {
    setSelectedAppointment(appointment)
    setTimeout(() => {
      window.print()
    }, 100)
  }

  return (
    <div className="container mx-auto px-4 py-8">
      <Card>
        <CardHeader>
          <CardTitle>{t("yourAppointments")}</CardTitle>
          <CardDescription>{t("viewAppointmentsDesc")}</CardDescription>
        </CardHeader>
        <CardContent>
          {appointments.length > 0 ? (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>{t("serialNumber")}</TableHead>
                  <TableHead>{t("patientName")}</TableHead>
                  <TableHead>{t("doctor")}</TableHead>
                  <TableHead className="hidden md:table-cell">{t("appointmentDate")}</TableHead>
                  <TableHead className="hidden md:table-cell">{t("status")}</TableHead>
                  <TableHead>{t("actions")}</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {appointments.map((appointment, index) => (
                  <TableRow key={appointment.id}>
                    <TableCell>{index + 1}</TableCell>
                    <TableCell className="font-medium">{appointment.name}</TableCell>
                    <TableCell>{getDoctorName(appointment.doctorId)}</TableCell>
                    <TableCell className="hidden md:table-cell">{formatDate(appointment.date)}</TableCell>
                    <TableCell className="hidden md:table-cell">
                      <span className="inline-flex items-center rounded-full px-2.5 py-0.5 text-xs font-medium bg-green-100 text-green-800">
                        {t(appointment.status)}
                      </span>
                    </TableCell>
                    <TableCell>
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => downloadPrescription(appointment)}
                        className="flex items-center gap-1"
                      >
                        <Download className="h-4 w-4" />
                        <span className="hidden sm:inline">{t("prescription")}</span>
                      </Button>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          ) : (
            <div className="text-center py-8">
              <p>{t("noAppointments")}</p>
            </div>
          )}
        </CardContent>
      </Card>

      {selectedAppointment && (
        <div className="hidden print:block p-8">
          <div className="max-w-4xl mx-auto border border-gray-200 p-8 rounded-lg">
            <div className="flex justify-between items-start">
              <div>
                <h1 className="text-2xl font-bold text-primary">Med Care</h1>
                <p className="text-sm text-gray-500">123 Hospital Street, Medical District</p>
                <p className="text-sm text-gray-500">Phone: +91 98765 43210</p>
              </div>
              <div className="text-right">
                <h2 className="text-xl font-semibold">{t("prescription")}</h2>
                <p className="text-sm text-gray-500">{formatDate(selectedAppointment.date)}</p>
                <p className="text-sm text-gray-500">ID: {selectedAppointment.id}</p>
              </div>
            </div>

            <div className="mt-8 border-t border-gray-200 pt-4">
              <h3 className="font-medium">{t("patientDetails")}</h3>
              <div className="grid grid-cols-2 gap-4 mt-2">
                <div>
                  <p className="text-sm text-gray-500">{t("patientName")}</p>
                  <p>{selectedAppointment.name}</p>
                </div>
                <div>
                  <p className="text-sm text-gray-500">
                    {t("age")} / {t("gender")}
                  </p>
                  <p>
                    {selectedAppointment.age} / {t(selectedAppointment.gender)}
                  </p>
                </div>
                <div>
                  <p className="text-sm text-gray-500">{t("mobileNumber")}</p>
                  <p>{selectedAppointment.mobile}</p>
                </div>
                <div>
                  <p className="text-sm text-gray-500">{t("emailAddress")}</p>
                  <p>{selectedAppointment.email}</p>
                </div>
              </div>
            </div>

            <div className="mt-6 border-t border-gray-200 pt-4">
              <h3 className="font-medium">{t("doctorDetails")}</h3>
              <p className="mt-2">{getDoctorName(selectedAppointment.doctorId)}</p>
              <p className="text-sm text-gray-500">
                {doctors.find((d) => d.id === selectedAppointment.doctorId)?.specialty}
              </p>
            </div>

            <div className="mt-6 border-t border-gray-200 pt-4">
              <h3 className="font-medium">{t("diagnosis")}</h3>
              <p className="mt-2">{selectedAppointment.disease}</p>
            </div>

            <div className="mt-6 border-t border-gray-200 pt-4">
              <h3 className="font-medium">{t("prescribedMedication")}</h3>
              <ul className="mt-2 space-y-2">
                <li>1. Paracetamol 500mg - 1 tablet three times a day after meals</li>
                <li>2. Vitamin C 500mg - 1 tablet daily</li>
                <li>3. Rest for 3 days</li>
              </ul>
            </div>

            <div className="mt-8 pt-8 border-t border-gray-200 text-right">
              <p className="font-medium">{getDoctorName(selectedAppointment.doctorId)}</p>
              <p className="text-sm text-gray-500">{t("signature")}</p>
            </div>

            <div className="mt-8 pt-4 border-t border-gray-200 text-center text-sm text-gray-500">
              <p>{t("prescriptionNote")}</p>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}
