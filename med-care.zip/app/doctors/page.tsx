import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Badge } from "@/components/ui/badge"

export default function DoctorsPage() {
  const doctors = [
    {
      id: 1,
      name: "Dr. Rajesh Kumar",
      specialty: "Cardiology",
      experience: "15+ years",
      education: "MBBS, MD (Cardiology)",
      languages: ["English", "Hindi", "Tamil"],
      image: "/placeholder.svg?height=100&width=100",
    },
    {
      id: 2,
      name: "Dr. Priya Sharma",
      specialty: "Neurology",
      experience: "12+ years",
      education: "MBBS, MD (Neurology)",
      languages: ["English", "Hindi", "Tamil"],
      image: "/placeholder.svg?height=100&width=100",
    },
    {
      id: 3,
      name: "Dr. Anand Patel",
      specialty: "Orthopedics",
      experience: "10+ years",
      education: "MBBS, MS (Orthopedics)",
      languages: ["English", "Tamil"],
      image: "/placeholder.svg?height=100&width=100",
    },
    {
      id: 4,
      name: "Dr. Meena Gupta",
      specialty: "Pediatrics",
      experience: "8+ years",
      education: "MBBS, MD (Pediatrics)",
      languages: ["English", "Hindi", "Tamil"],
      image: "/placeholder.svg?height=100&width=100",
    },
    {
      id: 5,
      name: "Dr. Suresh Reddy",
      specialty: "Dermatology",
      experience: "14+ years",
      education: "MBBS, MD (Dermatology)",
      languages: ["English", "Telugu", "Tamil"],
      image: "/placeholder.svg?height=100&width=100",
    },
    {
      id: 6,
      name: "Dr. Lakshmi Narayan",
      specialty: "Gynecology",
      experience: "18+ years",
      education: "MBBS, MD (Gynecology)",
      languages: ["English", "Tamil"],
      image: "/placeholder.svg?height=100&width=100",
    },
    {
      id: 7,
      name: "Dr. Karthik Raman",
      specialty: "ENT Specialist",
      experience: "9+ years",
      education: "MBBS, MS (ENT)",
      languages: ["English", "Tamil", "Malayalam"],
      image: "/placeholder.svg?height=100&width=100",
    },
    {
      id: 8,
      name: "Dr. Sanjana Krishnan",
      specialty: "Psychiatry",
      experience: "11+ years",
      education: "MBBS, MD (Psychiatry)",
      languages: ["English", "Tamil", "Hindi"],
      image: "/placeholder.svg?height=100&width=100",
    },
  ]

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="text-center mb-8">
        <h1 className="text-3xl font-bold tracking-tight">Our Specialist Doctors</h1>
        <p className="text-muted-foreground mt-2">Meet our team of experienced and qualified medical professionals</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {doctors.map((doctor) => (
          <Card key={doctor.id}>
            <CardHeader className="flex flex-row items-center gap-4 pb-2">
              <Avatar className="h-16 w-16">
                <AvatarImage src={doctor.image || "/placeholder.svg"} alt={doctor.name} />
                <AvatarFallback>
                  {doctor.name
                    .split(" ")
                    .map((n) => n[0])
                    .join("")}
                </AvatarFallback>
              </Avatar>
              <div>
                <CardTitle className="text-xl">{doctor.name}</CardTitle>
                <CardDescription>{doctor.specialty}</CardDescription>
              </div>
            </CardHeader>
            <CardContent>
              <div className="grid gap-2">
                <div className="flex items-center justify-between">
                  <span className="text-sm font-medium">Experience:</span>
                  <span className="text-sm">{doctor.experience}</span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-sm font-medium">Education:</span>
                  <span className="text-sm">{doctor.education}</span>
                </div>
                <div className="flex flex-wrap gap-1 mt-2">
                  {doctor.languages.map((language) => (
                    <Badge key={language} variant="secondary" className="text-xs">
                      {language}
                    </Badge>
                  ))}
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  )
}
