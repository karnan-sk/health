import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Button } from "@/components/ui/button"
import { MapPin, Phone, Mail, Clock, Facebook, Twitter, Instagram, Linkedin } from "lucide-react"

export default function ContactUsPage() {
  const contactInfo = [
    {
      id: 1,
      name: "Main Hospital",
      address: "123 Medical Avenue, Chennai, Tamil Nadu 600001",
      phone: "+91 44 2345 6789",
      email: "info@medcare.com",
      hours: "24/7 Emergency Services",
      mapUrl: "https://maps.google.com",
    },
    {
      id: 2,
      name: "Outpatient Center",
      address: "456 Health Street, Chennai, Tamil Nadu 600002",
      phone: "+91 44 2345 6790",
      email: "outpatient@medcare.com",
      hours: "Mon-Sat: 8:00 AM - 8:00 PM",
      mapUrl: "https://maps.google.com",
    },
    {
      id: 3,
      name: "Specialty Clinic",
      address: "789 Wellness Road, Chennai, Tamil Nadu 600003",
      phone: "+91 44 2345 6791",
      email: "specialty@medcare.com",
      hours: "Mon-Fri: 9:00 AM - 6:00 PM",
      mapUrl: "https://maps.google.com",
    },
  ]

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="text-center mb-8">
        <h1 className="text-3xl font-bold tracking-tight">Contact Us</h1>
        <p className="text-muted-foreground mt-2">Get in touch with our healthcare professionals</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 mb-12">
        {contactInfo.map((location) => (
          <Card key={location.id}>
            <CardHeader>
              <CardTitle>{location.name}</CardTitle>
              <CardDescription>Med Care Healthcare</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-start gap-3">
                <MapPin className="h-5 w-5 text-primary mt-0.5 shrink-0" />
                <span>{location.address}</span>
              </div>
              <div className="flex items-center gap-3">
                <Phone className="h-5 w-5 text-primary shrink-0" />
                <span>{location.phone}</span>
              </div>
              <div className="flex items-center gap-3">
                <Mail className="h-5 w-5 text-primary shrink-0" />
                <span>{location.email}</span>
              </div>
              <div className="flex items-center gap-3">
                <Clock className="h-5 w-5 text-primary shrink-0" />
                <span>{location.hours}</span>
              </div>
              <div className="pt-2">
                <a
                  href={location.mapUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-primary hover:underline text-sm font-medium"
                >
                  View on Google Maps
                </a>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        <Card>
          <CardHeader>
            <CardTitle>Send Us a Message</CardTitle>
            <CardDescription>Fill out the form below and we'll get back to you as soon as possible</CardDescription>
          </CardHeader>
          <CardContent>
            <form className="space-y-4">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <label htmlFor="name" className="text-sm font-medium">
                    Full Name
                  </label>
                  <Input id="name" placeholder="Enter your name" />
                </div>
                <div className="space-y-2">
                  <label htmlFor="email" className="text-sm font-medium">
                    Email Address
                  </label>
                  <Input id="email" type="email" placeholder="Enter your email" />
                </div>
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <label htmlFor="phone" className="text-sm font-medium">
                    Phone Number
                  </label>
                  <Input id="phone" placeholder="Enter your phone number" />
                </div>
                <div className="space-y-2">
                  <label htmlFor="subject" className="text-sm font-medium">
                    Subject
                  </label>
                  <Input id="subject" placeholder="Enter subject" />
                </div>
              </div>
              <div className="space-y-2">
                <label htmlFor="message" className="text-sm font-medium">
                  Message
                </label>
                <Textarea id="message" placeholder="Enter your message" className="min-h-[120px]" />
              </div>
              <Button type="submit" className="w-full">
                Send Message
              </Button>
            </form>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Emergency Contact</CardTitle>
            <CardDescription>For medical emergencies, please call our emergency hotline</CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="bg-red-50 border border-red-200 rounded-lg p-4 flex items-center gap-4">
              <div className="bg-red-100 p-3 rounded-full">
                <Phone className="h-6 w-6 text-red-600" />
              </div>
              <div>
                <h3 className="font-medium text-red-700">Emergency Hotline</h3>
                <p className="text-2xl font-bold text-red-600">+91 1800 123 4567</p>
                <p className="text-sm text-red-600">Available 24/7</p>
              </div>
            </div>

            <div>
              <h3 className="font-medium mb-3">Ambulance Services</h3>
              <p className="text-sm text-muted-foreground mb-2">
                Our ambulance services are available 24/7 for emergency situations. Call our emergency hotline to
                request an ambulance.
              </p>
              <p className="text-lg font-medium">+91 1800 123 4568</p>
            </div>

            <div>
              <h3 className="font-medium mb-3">Connect With Us</h3>
              <div className="flex space-x-4">
                <a href="#" className="bg-muted hover:bg-muted/80 p-2 rounded-full transition-colors">
                  <Facebook className="h-5 w-5" />
                  <span className="sr-only">Facebook</span>
                </a>
                <a href="#" className="bg-muted hover:bg-muted/80 p-2 rounded-full transition-colors">
                  <Twitter className="h-5 w-5" />
                  <span className="sr-only">Twitter</span>
                </a>
                <a href="#" className="bg-muted hover:bg-muted/80 p-2 rounded-full transition-colors">
                  <Instagram className="h-5 w-5" />
                  <span className="sr-only">Instagram</span>
                </a>
                <a href="#" className="bg-muted hover:bg-muted/80 p-2 rounded-full transition-colors">
                  <Linkedin className="h-5 w-5" />
                  <span className="sr-only">LinkedIn</span>
                </a>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
