"use client"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { zodResolver } from "@hookform/resolvers/zod"
import { useForm } from "react-hook-form"
import * as z from "zod"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"
import { Textarea } from "@/components/ui/textarea"
import { useToast } from "@/components/ui/use-toast"
import { useTranslation } from "@/components/language-provider"

const formSchema = z.object({
  name: z.string().min(2, {
    message: "Name must be at least 2 characters.",
  }),
  age: z.string().refine((val) => !isNaN(Number(val)) && Number(val) > 0 && Number(val) < 120, {
    message: "Age must be a valid number between 1 and 120.",
  }),
  gender: z.enum(["male", "female", "other"]),
  mobile: z.string().min(10, {
    message: "Mobile number must be at least 10 digits.",
  }),
  email: z.string().email({
    message: "Please enter a valid email address.",
  }),
  disease: z.string().min(2, {
    message: "Please describe your condition.",
  }),
  doctorId: z.string().min(1, {
    message: "Please select a doctor.",
  }),
})

export default function BookAppointmentPage() {
  const { t, language } = useTranslation()
  const { toast } = useToast()
  const router = useRouter()
  const [step, setStep] = useState(1)

  const doctors = [
    { id: "1", name: "Dr. Rajesh Kumar", specialty: "Cardiology" },
    { id: "2", name: "Dr. Priya Sharma", specialty: "Neurology" },
    { id: "3", name: "Dr. Anand Patel", specialty: "Orthopedics" },
    { id: "4", name: "Dr. Meena Gupta", specialty: "Pediatrics" },
    { id: "5", name: "Dr. Suresh Reddy", specialty: "Dermatology" },
  ]

  const form = useForm<z.infer<typeof formSchema>>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      name: "",
      age: "",
      gender: "male",
      mobile: "",
      email: "",
      disease: "",
      doctorId: "",
    },
  })

  function onSubmit(values: z.infer<typeof formSchema>) {
    if (step === 1) {
      setStep(2)
      return
    }

    // In a real app, you would send this data to your backend
    const appointmentData = {
      ...values,
      id: Date.now().toString(),
      date: new Date().toISOString(),
      status: "pending",
    }

    // Store in localStorage for demo purposes
    const appointments = JSON.parse(localStorage.getItem("appointments") || "[]")
    appointments.push(appointmentData)
    localStorage.setItem("appointments", JSON.stringify(appointments))

    toast({
      title: t("appointmentBooked"),
      description: t("appointmentConfirmation"),
    })

    router.push("/view-appointments")
  }

  const selectedDoctor = doctors.find((doctor) => doctor.id === form.watch("doctorId"))

  return (
    <div className="container mx-auto px-4 py-8">
      <Card className="max-w-2xl mx-auto">
        <CardHeader>
          <CardTitle>{t("bookAppointment")}</CardTitle>
          <CardDescription>{t("bookAppointmentDesc")}</CardDescription>
        </CardHeader>
        <CardContent>
          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
              {step === 1 ? (
                <>
                  <FormField
                    control={form.control}
                    name="name"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>{t("patientName")}</FormLabel>
                        <FormControl>
                          <Input placeholder={t("enterName")} {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <FormField
                      control={form.control}
                      name="age"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>{t("age")}</FormLabel>
                          <FormControl>
                            <Input type="number" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <FormField
                      control={form.control}
                      name="gender"
                      render={({ field }) => (
                        <FormItem className="space-y-3">
                          <FormLabel>{t("gender")}</FormLabel>
                          <FormControl>
                            <RadioGroup
                              onValueChange={field.onChange}
                              defaultValue={field.value}
                              className="flex space-x-4"
                            >
                              <FormItem className="flex items-center space-x-2 space-y-0">
                                <FormControl>
                                  <RadioGroupItem value="male" />
                                </FormControl>
                                <FormLabel className="font-normal">{t("male")}</FormLabel>
                              </FormItem>
                              <FormItem className="flex items-center space-x-2 space-y-0">
                                <FormControl>
                                  <RadioGroupItem value="female" />
                                </FormControl>
                                <FormLabel className="font-normal">{t("female")}</FormLabel>
                              </FormItem>
                              <FormItem className="flex items-center space-x-2 space-y-0">
                                <FormControl>
                                  <RadioGroupItem value="other" />
                                </FormControl>
                                <FormLabel className="font-normal">{t("other")}</FormLabel>
                              </FormItem>
                            </RadioGroup>
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <FormField
                      control={form.control}
                      name="mobile"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>{t("mobileNumber")}</FormLabel>
                          <FormControl>
                            <Input placeholder="9876543210" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <FormField
                      control={form.control}
                      name="email"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>{t("emailAddress")}</FormLabel>
                          <FormControl>
                            <Input type="email" placeholder="example@email.com" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>

                  <FormField
                    control={form.control}
                    name="disease"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>{t("medicalCondition")}</FormLabel>
                        <FormControl>
                          <Textarea placeholder={t("describeMedicalCondition")} className="resize-none" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={form.control}
                    name="doctorId"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>{t("selectDoctor")}</FormLabel>
                        <Select onValueChange={field.onChange} defaultValue={field.value}>
                          <FormControl>
                            <SelectTrigger>
                              <SelectValue placeholder={t("selectDoctorPlaceholder")} />
                            </SelectTrigger>
                          </FormControl>
                          <SelectContent>
                            {doctors.map((doctor) => (
                              <SelectItem key={doctor.id} value={doctor.id}>
                                {doctor.name} - {doctor.specialty}
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <Button type="submit" className="w-full">
                    {t("reviewDetails")}
                  </Button>
                </>
              ) : (
                <>
                  <div className="space-y-4">
                    <h3 className="text-lg font-medium">{t("reviewYourDetails")}</h3>

                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <p className="text-sm font-medium text-muted-foreground">{t("patientName")}</p>
                        <p>{form.getValues("name")}</p>
                      </div>

                      <div>
                        <p className="text-sm font-medium text-muted-foreground">{t("age")}</p>
                        <p>{form.getValues("age")}</p>
                      </div>

                      <div>
                        <p className="text-sm font-medium text-muted-foreground">{t("gender")}</p>
                        <p>{t(form.getValues("gender"))}</p>
                      </div>

                      <div>
                        <p className="text-sm font-medium text-muted-foreground">{t("mobileNumber")}</p>
                        <p>{form.getValues("mobile")}</p>
                      </div>

                      <div>
                        <p className="text-sm font-medium text-muted-foreground">{t("emailAddress")}</p>
                        <p>{form.getValues("email")}</p>
                      </div>

                      <div>
                        <p className="text-sm font-medium text-muted-foreground">{t("selectedDoctor")}</p>
                        <p>
                          {selectedDoctor?.name} - {selectedDoctor?.specialty}
                        </p>
                      </div>
                    </div>

                    <div>
                      <p className="text-sm font-medium text-muted-foreground">{t("medicalCondition")}</p>
                      <p>{form.getValues("disease")}</p>
                    </div>
                  </div>

                  <div className="flex space-x-4">
                    <Button variant="outline" type="button" onClick={() => setStep(1)}>
                      {t("back")}
                    </Button>
                    <Button type="submit" className="flex-1">
                      {t("confirmAppointment")}
                    </Button>
                  </div>
                </>
              )}
            </form>
          </Form>
        </CardContent>
      </Card>
    </div>
  )
}
